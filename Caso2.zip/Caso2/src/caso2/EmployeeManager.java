/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package caso2;

/**
 *
 * @author Joaquin
 */
import java.util.ArrayList;
import java.util.List;

interface Observer {
    void update(String data);
}

class EmployeeManager {
    private List<Observer> observers = new ArrayList<>();
    private String employeeData;

    public void addObserver(Observer o) {
        observers.add(o);
    }

    public void removeObserver(Observer o) {
        observers.remove(o);
    }

    public void notifyObservers() {
        for (Observer observer : observers) {
            observer.update(employeeData);
        }
    }

    public void changeEmployeeData(String data) {
        this.employeeData = data;
        notifyObservers();
    }
}