/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package caso2;

/**
 *
 * @author Joaquin
 */
public class Main {
    public static void main(String[] args) {
        EmployeeManager manager = new EmployeeManager();
        
        Supervisor supervisor1 = new Supervisor();
        Supervisor supervisor2 = new Supervisor();
        
        manager.addObserver(supervisor1);
        manager.addObserver(supervisor2);
        
        manager.changeEmployeeData("New Hire: John Doe");
        manager.changeEmployeeData("Promotion: Jane Smith");
    }
}
