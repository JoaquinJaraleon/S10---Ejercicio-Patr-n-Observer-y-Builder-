/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package caso1;

/**
 *
 * @author Joaquin
 */
public class Main {
    public static void main(String[] args) {
        WallpaperSelector selector = new WallpaperSelector();
        
        DesignerOne d1 = new DesignerOne();
        DesignerTwo d2 = new DesignerTwo();
        DesignerThree d3 = new DesignerThree();
        
        selector.addObserver(d1);
        selector.addObserver(d2);
        selector.addObserver(d3);
        
        selector.setWallpaper("Red");
        selector.setWallpaper("Blue");
    }
}