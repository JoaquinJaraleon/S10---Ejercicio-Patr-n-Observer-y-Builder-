/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package caso1;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Joaquin
 */
interface Observer {
    void update(String color);
}

class WallpaperSelector {
    private List<Observer> observers = new ArrayList<>();
    private String wallpaperColor;

    public void addObserver(Observer o) {
        observers.add(o);
    }

    public void removeObserver(Observer o) {
        observers.remove(o);
    }

    public void notifyObservers() {
        for (Observer observer : observers) {
            observer.update(wallpaperColor);
        }
    }

    public void setWallpaper(String color) {
        this.wallpaperColor = color;
        notifyObservers();
    }
}

